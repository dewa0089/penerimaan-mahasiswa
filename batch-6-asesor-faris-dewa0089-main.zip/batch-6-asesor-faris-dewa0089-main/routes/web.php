<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\PembayaranController;
use App\Http\Controllers\CalonMahasiswaController;
use App\Http\Controllers\PengumumanController;
use App\Http\Controllers\auth\AuthController;

// Guest Routes (belum login)
Route::middleware('guest')->group(function () {
    Route::get('/login', [AuthController::class, 'showLogin'])->name('login');
    Route::post('/login', [AuthController::class, 'login']);
    Route::get('/register', [AuthController::class, 'showRegister'])->name('register');
    Route::post('/register', [AuthController::class, 'register']);
    
});

Route::middleware(['auth'])->group(function () {
    Route::get('/status-akun', [AuthController::class, 'prosesAkun'])
        ->name('status.akun');
});

Route::middleware(['auth', 'checkRole:A'])->group(function () {
    Route::get('/proses-akun', [AuthController::class, 'prosesAkun'])
        ->name('akun.proses');
    Route::get('/proses-akun/approve/{id}', [AuthController::class, 'approve'])
        ->name('akun.approve');
    Route::get('/proses-akun/reject/{id}', [AuthController::class, 'reject'])
        ->name('akun.reject');
});

// Authenticated Routes (harus login)
Route::middleware('auth')->group(function () {
    Route::post('/logout', [AuthController::class, 'logout'])->name('logout');

    // Pendaftaran
    Route::middleware(['checkRole:U', 'akunApproved'])->group(function () {
        Route::get('/pendaftaran', fn() => view('pendaftaran.index'))->name('pendaftaran.index');
        Route::post('/pendaftaran/proses', [CalonMahasiswaController::class, 'proses'])->name('pendaftaran.proses');

        Route::get('/pembayaran/create/{id}', [PembayaranController::class, 'createPayment'])->name('pembayaran.create');
        Route::post('/pembayaran/upload/{id}', [PembayaranController::class, 'uploadBukti'])->name('pembayaran.upload');
    });

    Route::middleware('checkRole:A')->group(function () {
        Route::get('/pendaftaran/{id}/approve', [CalonMahasiswaController::class, 'approve'])
            ->name('pendaftaran.approve');
        Route::get('/pendaftaran/{id}/reject', [CalonMahasiswaController::class, 'reject'])
            ->name('pendaftaran.reject');
    });

    Route::middleware(['checkRole:A,U', 'akunApproved'])->group(function () {
        Route::get('/pembayaran', [PembayaranController::class, 'index'])->name('pembayaran.index');
    });

    Route::middleware('checkRole:A')->group(function () {
        Route::get('/pembayaran/approve/{id}', [PembayaranController::class, 'approve'])->name('pembayaran.approve');
        Route::get('/pembayaran/reject/{id}', [PembayaranController::class, 'reject'])->name('pembayaran.reject');
    });

    // Pengumuman (hanya untuk admin)
    Route::middleware('checkRole:A')->group(function () {
        Route::get('/pengumuman/create', [PengumumanController::class, 'create'])->name('pengumuman.create');
        Route::post('/pengumuman/store', [PengumumanController::class, 'store'])->name('pengumuman.store');
        Route::get('/pengumuman/{id}/edit', [PengumumanController::class, 'edit'])->name('pengumuman.edit');
        Route::put('/pengumuman/{id}', [PengumumanController::class, 'update'])->name('pengumuman.update');
        Route::delete('/pengumuman/{id}', [PengumumanController::class, 'destroy'])->name('pengumuman.destroy');
    });
});

// Public Routes (bisa diakses semua orang)
Route::get('/', function () {
    return view('welcome');
});

// Pengumuman bisa dilihat semua orang
Route::get('/pengumuman', [PengumumanController::class, 'index'])->name('pengumuman.index');
Route::get('/pengumuman/{id}', [PengumumanController::class, 'show'])->name('pengumuman.show');
