<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Pengumuman extends Model
{
    
    public $incrementing = false;
    protected $keyType = 'string';

    protected $table = 'pengumumans';

    protected $fillable = [
    'id',
    'judul',
    'isi',
    'gambar',
    'tgl_pengumuman'
];



}
