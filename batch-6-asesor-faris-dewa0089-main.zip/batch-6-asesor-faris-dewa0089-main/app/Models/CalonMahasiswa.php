<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Concerns\HasUuids;

class CalonMahasiswa extends Model
{
    use HasFactory, HasUuids;

    protected $table = 'calon_mahasiswas';
    protected $fillable = ['nama','jk','jurusan','agama','tgl_lahir','alamat','nisn','nomor','email','status','user_id'];

    public function pembayaran()
    {
        return $this->hasOne(Pembayaran::class, 'calon_mahasiswa_id');
    }
}
