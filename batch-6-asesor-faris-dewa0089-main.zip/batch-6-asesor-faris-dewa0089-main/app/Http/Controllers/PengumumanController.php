<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Pengumuman;
use Illuminate\Support\Str;

class PengumumanController extends Controller
{
    public function index()
    {
        $data = Pengumuman::orderBy('tgl_pengumuman', 'desc')->orderBy('created_at', 'desc')->get();
        return view('pengumuman.index', compact('data'));
    }

    public function create()
    {
        return view('pengumuman.create');
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'judul'  => 'required|string|max:255',
            'isi'    => 'required|string',
            'gambar' => 'nullable|image|mimes:jpg,jpeg,png|max:2048'
        ]);

        // Upload gambar jika ada
        if ($request->hasFile('gambar')) {
            $filename = time() . '.' . $request->gambar->extension();
            $request->gambar->move(public_path('upload'), $filename);
            $validated['gambar'] = $filename;
        }

        // Generate UUID
        $validated['id'] = Str::uuid();

        // Tanggal otomatis
        $validated['tgl_pengumuman'] = now()->toDateString();

        Pengumuman::create($validated);

        return redirect()->route('pengumuman.index')
                         ->with('success', 'Pengumuman berhasil ditambahkan.');
    }

    public function show($id)
    {
        $p = Pengumuman::findOrFail($id);
        return view('pengumuman.show', compact('p'));
    }

    // EDIT
    public function edit($id)
    {
        $p = Pengumuman::findOrFail($id);
        return view('pengumuman.edit', compact('p'));
    }

    // UPDATE
    public function update(Request $request, $id)
    {
        $p = Pengumuman::findOrFail($id);

        $validated = $request->validate([
            'judul'  => 'required|string|max:255',
            'isi'    => 'required|string',
            'gambar' => 'nullable|image|mimes:jpg,jpeg,png|max:2048'
        ]);

        // Jika ada gambar baru diupload
        if ($request->hasFile('gambar')) {

            // Hapus gambar lama jika ada
            if ($p->gambar && file_exists(public_path('upload/' . $p->gambar))) {
                unlink(public_path('upload/' . $p->gambar));
            }

            $filename = time() . '.' . $request->gambar->extension();
            $request->gambar->move(public_path('upload'), $filename);
            $validated['gambar'] = $filename;
        }

        $p->update($validated);

        return redirect()->route('pengumuman.index')
                         ->with('success', 'Pengumuman berhasil diperbarui.');
    }

    // DELETE
    public function destroy($id)
    {
        $p = Pengumuman::findOrFail($id);

        // Hapus file gambar jika ada
        if ($p->gambar && file_exists(public_path('upload/' . $p->gambar))) {
            unlink(public_path('upload/' . $p->gambar));
        }

        $p->delete();

        return redirect()->route('pengumuman.index')
                         ->with('success', 'Pengumuman berhasil dihapus.');
    }
}
