<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Pembayaran;
use App\Models\CalonMahasiswa;
use Illuminate\Support\Facades\Storage;

class PembayaranController extends Controller
{
    public function index()
{
    if (auth()->user()->role === 'A') {
        // Admin: tampilkan semua pendaftar beserta pembayaran
        $pendaftar = CalonMahasiswa::with('pembayaran')
        ->orderBy('created_at', 'desc')
        ->get();
    } else {
        // User: tampilkan hanya data miliknya
        $pendaftar = CalonMahasiswa::with('pembayaran')
            ->where('user_id', auth()->id())
            ->orderBy('created_at', 'desc') 
            ->get();
    }

    return view('pembayaran.index', compact('pendaftar'));
}


    public function createPayment($id)
    {
        $calon = CalonMahasiswa::where('id', $id)
    ->where('user_id', auth()->id())
    ->firstOrFail();
        return view('pembayaran.create', compact('calon'));
    }

    public function uploadBukti(Request $request, $id)
    {
        $request->validate([
            'bukti' => 'required|mimes:jpg,png,jpeg,pdf|max:2048'
        ]);

        $pembayaran = Pembayaran::findOrFail($id);
        $fileName = time().'_'.$request->bukti->getClientOriginalName();
        $request->bukti->move(public_path('bukti'), $fileName);

        $pembayaran->update([
            'bukti' => $fileName,
            'tgl_pembayaran' => now()->toDateString(),
            'status' => 'pending',
        ]);

        return redirect()->route('pembayaran.index')->with('success', 'Bukti pembayaran berhasil diunggah.');
    }

    public function approve($id)
    {
        $pembayaran = Pembayaran::findOrFail($id);
        $pembayaran->update(['status' => 'Pembayaran Diterima']);
        return redirect()->back()->with('success', 'Pembayaran disetujui.');
    }

    public function reject($id)
    {
        $pembayaran = Pembayaran::findOrFail($id);
        $pembayaran->update(['status' => 'Pembayaran Ditolak']);
        return redirect()->back()->with('success', 'Pembayaran ditolak.');
    }
}
