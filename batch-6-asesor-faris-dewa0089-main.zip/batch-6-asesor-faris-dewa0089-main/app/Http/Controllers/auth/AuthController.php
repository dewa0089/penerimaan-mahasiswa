<?php

namespace App\Http\Controllers\auth;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\User;
use Illuminate\Support\Facades\Hash;

class AuthController extends Controller
{
    // ---------------------------
    // Show Login Page
    // ---------------------------
    public function showLogin()
    {
        return view('auth.login');
    }

    // ---------------------------
    // Show Register Page
    // ---------------------------
    public function showRegister()
    {
        return view('auth.register');
    }

    // ---------------------------
    // Login
    // ---------------------------
    public function login(Request $request)
{
    $credentials = $request->validate([
        'email'    => 'required|email',
        'password' => 'required',
    ]);

    if (Auth::attempt($credentials)) {
        $request->session()->regenerate();

        if (Auth::user()->status !== 'approved') {
            return redirect()->route('status.akun')
                ->with('message', 'Akun Anda sedang menunggu persetujuan admin.');
        }

        // Login berhasil
        return redirect('/')->with('success', 'Login berhasil!');
    }

    // Login gagal
    return back()->with('error', 'Email atau password salah.');
}


    // ---------------------------
    // Register
    // ---------------------------
    public function register(Request $request)
    {
        $request->validate([
            'name'      => 'required',
            'email'     => 'required|email|unique:users',
            'password'  => 'required|min:6|confirmed',
        ]);

        User::create([
            'name'        => $request->name,
            'email'       => $request->email,
            'password'    => Hash::make($request->password),
            'role'        => 'U',            // User default
            'status'      => 'pending',      // Belum disetujui admin
        ]);

        return redirect()->route('login')
                         ->with('success', 'Registrasi berhasil! Tunggu persetujuan admin.');
    }

    // ---------------------------
    // Logout
    // ---------------------------
    public function logout(Request $request)
    {
        Auth::logout();
        $request->session()->invalidate();
        $request->session()->regenerateToken();
        return redirect()->route('login');
    }


   public function prosesAkun()
{
    // Ambil semua user role U (user biasa)
    $users = User::where('role', 'U')->orderBy('created_at', 'desc')->get();

    return view('auth.proses', compact('users'));
}

public function approve($id)
{
    $user = User::findOrFail($id);
    $user->status = 'approved';
    $user->save();

    return redirect()->route('akun.proses')->with('success', 'Akun disetujui.');
}

public function reject($id)
{
    $user = User::findOrFail($id);
    $user->status = 'rejected';
    $user->save();

    return redirect()->route('akun.proses')->with('success', 'Akun ditolak.');
}




}
