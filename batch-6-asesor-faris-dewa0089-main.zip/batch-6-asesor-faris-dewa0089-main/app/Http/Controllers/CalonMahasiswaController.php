<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\CalonMahasiswa;
use App\Models\Pembayaran;
use Illuminate\Support\Str;

class CalonMahasiswaController extends Controller
{
    public function proses(Request $request)
{
    $request->validate([
        'nama' => 'required|string|max:255',
        'jk' => 'required|in:L,P',
        'jurusan' => 'required|string|max:100',
        'agama' => 'required|string|max:50',
        'tgl_lahir' => 'required|date',
        'alamat' => 'required|string|max:255',
        'nisn' => 'required|string|max:10',
        'nomor' => 'required|string|max:13',
        'email' => 'required|email|max:255',
    ]);

    // Simpan calon mahasiswa milik user login
    $calon = CalonMahasiswa::create([
        'nama' => $request->nama,
        'jk' => $request->jk,
        'jurusan' => $request->jurusan,
        'agama' => $request->agama,
        'tgl_lahir' => $request->tgl_lahir,
        'alamat' => $request->alamat,
        'nisn' => $request->nisn,
        'nomor' => $request->nomor,
        'email' => $request->email,
        'status' => 'pending',
        'user_id' => auth()->id(),    
    ]);

    // Total pembayaran 500.000
    $biaya = 500000;

    // Buat pembayaran milik calon mahasiswa ini
    Pembayaran::create([
        'calon_mahasiswa_id' => $calon->id,
        'total_pembayaran' => $biaya,
        'status' => 'pending',
        'tgl_tempo' => now()->addWeek()->toDateString(),
        'tgl_pembayaran' => null,
        'bukti' => null,
    ]);

    return redirect()->route('pembayaran.index')->with('success', 'Pendaftaran berhasil! Silahkan lakukan pembayaran.');
}

public function approve($id)
{
    $calon = CalonMahasiswa::findOrFail($id);
    $calon->update(['status' => 'Pendaftaran Diterima']);
    return redirect()->back()->with('success', 'Pendaftaran diterima.');
}

public function reject($id)
{
    $calon = CalonMahasiswa::findOrFail($id);
    $calon->update(['status' => 'Pendaftaran Ditolak']);
    return redirect()->back()->with('success', 'Pendaftaran ditolak.');
}


}
