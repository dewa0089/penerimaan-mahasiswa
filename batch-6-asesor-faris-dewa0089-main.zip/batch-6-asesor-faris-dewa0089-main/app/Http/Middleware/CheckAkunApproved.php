<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Symfony\Component\HttpFoundation\Response;

class CheckAkunApproved
{
    public function handle(Request $request, Closure $next): Response
    {
        // Jika user belum login → tolak
        if (!Auth::check()) {
            abort(403, 'Unauthorized');
        }

        // Hanya user yang status = 'approved' yang boleh lanjut
        if (Auth::user()->status !== 'approved') {
            abort(403, 'Akun Anda belum disetujui oleh admin.');
        }

        return $next($request);
    }
}
