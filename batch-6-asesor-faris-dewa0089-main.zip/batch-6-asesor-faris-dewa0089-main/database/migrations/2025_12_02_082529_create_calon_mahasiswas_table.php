<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('calon_mahasiswas', function (Blueprint $table) {
            $table->uuid('id');
            $table->primary('id');
            $table->String("nama");
            $table->enum('jk', ['L', 'P']);
            $table->String("nomor");
            $table->String("nisn");
            $table->String("email");
            $table->date("tgl_lahir");
            $table->String('alamat');
            $table->String('status');
            $table->String('agama');
            $table->String("jurusan");
            $table->timestamps();
            $table->unsignedBigInteger('user_id')->nullable();
            $table->foreign('user_id')->references('id')->on('users')->restrictOnDelete()->restrictOnUpdate();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('calon_mahasiswas');
    }
};
