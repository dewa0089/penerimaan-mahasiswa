@extends('layout.main')
@section('title', 'Dashboard')

@section('content')


<div id="hero" class="hero-carousel mx-auto">
    <div id="carouselExampleCaptions" class="carousel slide" data-bs-ride="carousel">
        <div class="carousel-inner">

            <div class="carousel-item active">
                <img src="images/1.jpeg" class="d-block w-100"
                     alt="slide 1" style="object-fit:cover; height: 500px;">
                <div class="carousel-caption d-none d-md-block hero-caption" style="bottom: 18%;">
    <h1>Bergabunglah bersama Kami dan Raih Kesuksesan</h1>
    <p style="color: white;">
        Institut Teknologi Nasional (ITN) Malang telah memperoleh peringkat Pertama Institut swasta se-Indonesia dari Kementerian Riset dan Teknologi Republik Indonesia.
    </p>
</div>
            </div>

            <div class="carousel-item">
                <img src="images/2.jpg" class="d-block w-100"
                     alt="slide 2" style="object-fit:cover; height: 500px;">
            </div>

            <div class="carousel-item">
                <img src="images/3.jpg" class="d-block w-100"
                     alt="slide 3" style="object-fit:cover; height: 500px;">
            </div>

        </div>

        <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Previous</span>
        </button>
        <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Next</span>
        </button>

    </div>
</div>

<section id="alur-pendaftaran" class="container py-5">
    <div class="title-brush-wrapper mb-4">
        <h2 class="title-brush">Alur Pendaftaran Mahasiswa Baru (PMB)</h2>
    </div>

    <div class="row g-5 text-center">
        @php
        $steps = [
            ['icon' => 'bi-file-earmark-richtext', 'title' => 'Melakukan Pendaftaran', 'desc' => 'Peserta mengisi biodata singkat dan memilih program studi yang diinginkan.'],
            ['icon' => 'bi-wallet2', 'title' => 'Membayar Biaya Pendaftaran', 'desc' => 'Pembayaran biaya pendaftaran dilakukan melalui virtual account.'],
            ['icon' => 'bi-file-earmark-person', 'title' => 'Melengkapi Biodata & Dokumen', 'desc' => 'Mengisi biodata lengkap serta mengunggah dokumen pendukung.'],
            ['icon' => 'bi-megaphone', 'title' => 'Validasi & Pengumuman', 'desc' => 'Hasil validasi diumumkan melalui Halaman Calon Mahasiswa Baru.'],
            ['icon' => 'bi-cash-coin', 'title' => 'Membayar Biaya Herregistrasi', 'desc' => 'Melunasi biaya pasca pendaftaran seperti UKT, uang gedung, dan lainnya.'],
            ['icon' => 'bi-person-check', 'title' => 'Menjadi Mahasiswa ITN Malang', 'desc' => 'Mahasiswa mengikuti perkuliahan dengan pembagian kelas yang ditentukan.'],
        ];
        @endphp

        @foreach($steps as $step)
        <div class="col-md-4">
            <div class="d-flex flex-column align-items-center min-vh-25" style="min-height:250px;">
                <div class="icon-wrapper d-flex justify-content-center align-items-center mb-3" style="height:85px; width:85px;">
                    <i class="bi {{ $step['icon'] }}" style="color: blue; font-size: 50px;"></i>
                </div>
                <h5 class="fw-semibold">{{ $loop->iteration }}. {{ $step['title'] }}</h5>
                <p class="text-muted">{{ $step['desc'] }}</p>
            </div>
        </div>
        @endforeach
    </div>
</section>

<section id="tentang-itn" class="container-fluid py-5" style="background:#FBEFEF;">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-md-6 mb-4">
                <h2 class="title-brush">Tentang</h2> 
                <h4 class="fw-bold mt-3">Institut Teknologi Nasional (ITN) Malang</h4>
                <p>
                    Institut Teknologi Nasional (ITN) Malang merupakan perguruan tinggi unggulan 
                    yang telah mencetak ribuan profesional berkualitas di bidang teknologi dan 
                    rekayasa. Dengan akreditasi institusi yang membanggakan, ITN Malang terus 
                    berinovasi melalui penelitian berkelas nasional dan internasional serta 
                    menjalin kerja sama strategis dengan berbagai industri. Komitmen terhadap 
                    pendidikan berkualitas dan pengembangan teknologi menjadikan ITN Malang 
                    sebagai salah satu pilar penting dalam mendukung kemajuan bangsa.
                </p>
            </div>

            <div class="col-md-6 text-center">
                <div class="ratio ratio-16x9 shadow-lg rounded-3" style="overflow:hidden;">
                    <iframe 
                        src="https://www.youtube.com/embed/pto3hGvan0I?autoplay=1&mute=1&loop=1&playlist=pto3hGvan0I&controls=0&showinfo=0&rel=0"
                        title="Video Profil ITN"
                        allow="autoplay"
                        allowfullscreen
                        style="border-radius: 10px;">
                    </iframe>
                </div>
            </div>
        </div>
    </div>
</section>

@endsection
