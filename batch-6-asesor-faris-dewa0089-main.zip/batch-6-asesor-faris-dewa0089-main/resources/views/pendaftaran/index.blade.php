@extends('layout.main')
@section('title', 'Pendaftaran')

@section('content')

<div class="container py-5 mt-5">

    <div class="row g-4">

        <div class="col-lg-8">

            <div class="card shadow-sm border-0 p-4" style="border-radius:16px;">
                
                <h4 class="fw-bold mb-1">Formulir Pendaftaran</h4>
                <p class="text-muted mb-4">Silahkan lengkapi data dengan mengisi formulir pendaftaran berikut.</p>

                <div class="p-3 border rounded-3 mb-4"
                     style="border-color:#b2a4ff !important;">
                    <div class="form-check">
                        <input class="form-check-input" type="radio" name="jenjang" value="S1" checked>
                        <label class="form-check-label fw-semibold">
                            Sarjana (S1)
                        </label>
                    </div>
                </div>

                <h5 class="fw-semibold mb-3">Biodata</h5>

                <form action="{{ route('pendaftaran.proses') }}" method="POST">
                    @csrf

                    <div class="mb-4">
                        <label class="form-label fw-semibold">Nama Lengkap</label>
                        <input type="text" class="form-control"
                            name="nama"
                            value="{{ auth()->user()->name }}"
                            readonly
                            style="background:#f0f0f0;">
                    </div>


                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label class="form-label fw-semibold">Jenis Kelamin</label>
                            <select class="form-select" name="jk" required>
                                <option value="">Pilih</option>
                                <option value="L">Laki-Laki</option>
                                <option value="P">Perempuan</option>
                            </select>
                        </div>

                        <div class="col-md-6">
                            <label class="form-label fw-semibold">Program Studi</label>
                            <select class="form-select" name="jurusan" required>
                                <option value="">Pilih</option>
                                <option value="Teknik Informatika">Teknik Informatika</option>
                                <option value="Manajemen">Manajemen</option>
                            </select>
                        </div>
                    </div>

                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label class="form-label fw-semibold">Agama</label>
                            <select class="form-select" name="agama" required>
                                <option value="">Pilih</option>
                                <option value="Buddha">Buddha</option>
                                <option value="Islam">Islam</option>
                            </select>
                        </div>

                        <div class="col-md-6">
                            <label class="form-label fw-semibold">Tanggal Lahir</label>
                            <input type="date" class="form-control" name="tgl_lahir" required>
                        </div>
                    </div>

                    <div class="mb-3">
                        <label class="form-label fw-semibold">Alamat</label>
                        <input type="text" class="form-control" name="alamat" placeholder="Alamat" required>
                    </div>

                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label class="form-label fw-semibold">NISN</label>
                            <input type="text" class="form-control" name="nisn" placeholder="NISN" 
                                   maxlength="10"
                                   oninput="this.value=this.value.replace(/[^0-9]/g,'')"
                                   required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-semibold">Nomor WhatsApp Pribadi</label>
                            <input type="text" class="form-control" name="nomor" placeholder="Nomor WhatsApp Pribadi"
                                   maxlength="13"
                                   oninput="this.value=this.value.replace(/[^0-9]/g,'')"
                                   required>
                        </div>
                    </div>

                    <div class="mb-4">
                        <label class="form-label fw-semibold">Email</label>
                        <input type="email" class="form-control" name="email" placeholder="Email" required>
                    </div>

                    <button type="submit" class="btn w-100 text-white fw-semibold"
                            style="background:#6d62ff; padding:10px 0; border-radius:8px;">
                        Proses Daftar
                    </button>

                </form>

            </div>
        </div>

        <div class="col-lg-4">

            <div class="card shadow-sm border-0 p-4 mb-4" style="border-radius:16px;">
                <h5 class="fw-semibold">Info Pendaftaran</h5>
                <p class="text-muted small">Apakah Anda telah melakukan pendaftaran?</p>

                <hr>

                <a href="{{ route('pembayaran.index') }}" 
                class="btn w-100 fw-semibold text-white" 
                style="background:#28a745;">
                Lihat Pendaftaran Saya →
                </a>

            </div>

        </div>
    </div>

</div>

@endsection
