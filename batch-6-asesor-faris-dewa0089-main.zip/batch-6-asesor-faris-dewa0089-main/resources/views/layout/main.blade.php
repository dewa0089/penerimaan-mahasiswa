<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />

  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">

  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">

  <link rel="stylesheet" href="{{ asset('styles/main.css') }}">

  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">

<title>@yield('title', 'PMB ITN Malang')</title>
<link rel="icon" type="image/png" href="{{ asset('images/ITN.png') }}">
 
</head>
<body>

    <nav class="navbar navbar-expand-lg navbar-floating">
  <div class="container-fluid px-2 px-lg-3">

    <a class="d-flex align-items-center text-decoration-none" href="{{ url('/') }}">
      <img src="{{ asset('images/ITN.png') }}" alt="ITN" width="44" height="44"
           class="me-2 rounded-circle">
      <div class="d-flex flex-column">
        <span class="fw-bold fs-5 m-0">PMB</span>
        <small class="text-muted" style="line-height:1;">Penerimaan Mahasiswa Baru</small>
      </div>
    </a>

    <button class="navbar-toggler ms-2" type="button" data-bs-toggle="collapse" data-bs-target="#navFloatContent"
            aria-controls="navFloatContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navFloatContent">

      <ul class="navbar-nav mx-lg-4 mb-2 mb-lg-0 align-items-lg-center">
        <li class="nav-item">
          <a class="nav-link {{ Request::is('/') ? 'active' : '' }}" href="{{ url('/') }}">Beranda</a>
        </li>
        @auth
        @if (auth()->user()->status === 'approved')
        @if (auth()->user()->role === 'U')
        <li class="nav-item">
          <a class="nav-link {{ Request::is('pendaftaran') ? 'active' : '' }}" href="{{ url('/pendaftaran') }}">Pendaftaran</a>
        </li>
        @endif
        <li class="nav-item">
          <a class="nav-link {{ Request::is('pembayaran') ? 'active' : '' }}" href="{{ url('/pembayaran') }}">Pembayaran</a>
        </li>
        @endif
        @endauth
        <li class="nav-item">
          <a class="nav-link {{ Request::is('pengumuman') ? 'active' : '' }}" href="{{ url('/pengumuman') }}">Pengumuman</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="{{ url('/#alur-pendaftaran') }}">Panduan</a>
        </li>
        @auth
        @if(in_array(Auth::user()->role, ['A', 'U']))
         <li class="nav-item">
          <a class="nav-link" href="{{ url('status-akun') }}">Status Akun</a>
        </li>
        @endif
        @endauth
      </ul>

      <div class="ms-auto d-flex align-items-center gap-3">

    @guest
        <a href="{{ route('login') }}" class="signin-btn">
            Sign In <i class="bi bi-box-arrow-in-right ms-2"></i>
        </a>
    @endguest

    @auth
        <div class="dropdown">
            <a class="btn btn-light dropdown-toggle fw-semibold" 
               href="#" 
               id="userMenu" 
               data-bs-toggle="dropdown" 
               aria-expanded="false">
                {{ Auth::user()->name }}
            </a>

            <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="userMenu">
                <li>
                    <form action="{{ route('logout') }}" method="POST">
                        @csrf
                        <button class="dropdown-item text-danger" type="submit">
                            <i class="bi bi-box-arrow-right me-2"></i> Logout
                        </button>
                    </form>
                </li>
            </ul>
        </div>
    @endauth
</div>

    </div>
  </div>
</nav>

<main class="content-wrapper">
    @yield('content')
</main>
<footer class="mt-5"
        style="
          background:#1A3D64;
          padding:25px 0 10px;
          border-top-left-radius: 25px;
          border-top-right-radius: 25px;
        ">

  <div class="container text-white-50">
    <div class="row align-items-center mb-3" style="row-gap:0;">

      <div class="col-md-2 text-center text-md-start mb-3 mb-md-0" style="padding-right:0;">
        <img src="{{ asset('images/ITN.png') }}" 
             alt="Logo ITN"
             width="130"
             class="rounded-circle shadow">
      </div>

      <div class="col-md-10 text-center text-md-start mt-2" style="padding-left:15px;">

        <h5 class="fw-bold text-white mb-1">Institut Teknologi Nasional (ITN) Malang</h5>

        <p class="mb-1">
          <i class="bi bi-geo-alt-fill me-2"></i>
          Jl. Raya Karanglo Km.2, Malang, Jawa Timur
        </p>

        <p class="mb-1">
          <i class="bi bi-telephone-fill me-2"></i>
          0341 – 478877
        </p>

        <div class="mt-1 d-flex gap-3 justify-content-center justify-content-md-start">

          <a href="https://www.instagram.com/itnmalang_official/" class="text-white" style="font-size:20px;">
            <i class="bi bi-instagram"></i>
          </a>

          <a href="https://wa.me/6281215166914" class="text-white" style="font-size:20px;">
            <i class="bi bi-whatsapp"></i>
          </a>

          <a href="https://www.youtube.com/watch?v=pto3hGvan0I" class="text-white" style="font-size:20px;">
            <i class="bi bi-youtube"></i>
          </a>

        </div>

<a href="https://wa.me/6281215166914" 
   target="_blank" 
   class="wa-floating">
    <i class="bi bi-whatsapp"></i>
</a>


      </div>
    </div>

    <hr class="border-light opacity-25">

    <div class="text-center">
      <small class="d-block">&copy; {{ date('Y') }} ITN Malang — Penerimaan Mahasiswa Baru</small>
      <small class="d-block">All Rights Reserved</small>
    </div>

  </div>
</footer>





<script>
document.addEventListener("scroll", function () {
    const navbar = document.querySelector(".navbar-floating");

    if (window.scrollY > 120) {
        navbar.classList.add("navbar-scrolled");
    } else {
        navbar.classList.remove("navbar-scrolled");
    }
});
</script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>

<script>
    @if(session('success'))
        toastr.success("{{ session('success') }}");
    @endif

    @if(session('error'))
        toastr.error("{{ session('error') }}");
    @endif

    @if(session('message'))
        toastr.info("{{ session('message') }}");
    @endif
</script>

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script>
    document.addEventListener('DOMContentLoaded', function () {
        const deleteButtons = document.querySelectorAll('.delete-btn');
        deleteButtons.forEach(button => {
            button.addEventListener('click', function () {
                const id = this.getAttribute('data-id');
                Swal.fire({
                    title: 'Yakin ingin menghapus?',
                    text: "Data pengumuman akan hilang!",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#d33',
                    cancelButtonColor: '#3085d6',
                    confirmButtonText: 'Ya, hapus!',
                    cancelButtonText: 'Batal'
                }).then((result) => {
                    if (result.isConfirmed) {
                        document.getElementById('delete-form-' + id).submit();
                    }
                });
            });
        });
    });



    document.addEventListener('DOMContentLoaded', function () {

    // Sweet Alert Pendaftaran 
    const approvePendaftaranButtons = document.querySelectorAll('.approve-pendaftaran');
    approvePendaftaranButtons.forEach(button => {
        button.addEventListener('click', function () {
            const id = this.dataset.id;
            Swal.fire({
                title: 'Terima pendaftaran?',
                text: "Calon mahasiswa akan diterima!",
                icon: 'question',
                showCancelButton: true,
                confirmButtonText: 'Ya, terima',
                cancelButtonText: 'Batal'
            }).then((result) => {
                if (result.isConfirmed) {
                    window.location.href = `/pendaftaran/${id}/approve`;
                }
            });
        });
    });

    const rejectPendaftaranButtons = document.querySelectorAll('.reject-pendaftaran');
    rejectPendaftaranButtons.forEach(button => {
        button.addEventListener('click', function () {
            const id = this.dataset.id;
            Swal.fire({
                title: 'Tolak pendaftaran?',
                text: "Calon mahasiswa akan ditolak!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonText: 'Ya, tolak',
                cancelButtonText: 'Batal'
            }).then((result) => {
                if (result.isConfirmed) {
                    window.location.href = `/pendaftaran/${id}/reject`;
                }
            });
        });
    });

    // Sweet Alert Pembayaran
    const approvePembayaranButtons = document.querySelectorAll('.approve-pembayaran');
    approvePembayaranButtons.forEach(button => {
        button.addEventListener('click', function () {
            const id = this.dataset.id;
            Swal.fire({
                title: 'Terima pembayaran?',
                text: "Pembayaran akan diterima!",
                icon: 'question',
                showCancelButton: true,
                confirmButtonText: 'Ya, terima',
                cancelButtonText: 'Batal'
            }).then((result) => {
                if (result.isConfirmed) {
                    window.location.href = `/pembayaran/approve/${id}`;
                }
            });
        });
    });

    const rejectPembayaranButtons = document.querySelectorAll('.reject-pembayaran');
    rejectPembayaranButtons.forEach(button => {
        button.addEventListener('click', function () {
            const id = this.dataset.id;
            Swal.fire({
                title: 'Tolak pembayaran?',
                text: "Pembayaran akan ditolak!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonText: 'Ya, tolak',
                cancelButtonText: 'Batal'
            }).then((result) => {
                if (result.isConfirmed) {
                    window.location.href = `/pembayaran/reject/${id}`;
                }
            });
        });
    });

});

</script>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
