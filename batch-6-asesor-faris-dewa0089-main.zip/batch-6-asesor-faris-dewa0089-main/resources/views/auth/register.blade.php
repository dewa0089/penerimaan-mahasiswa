@extends('layout.main')

@section('content')
<div class="container d-flex justify-content-center align-items-center" style="min-height: 100vh; margin-top: 100px;">

    <div class="row w-100 shadow-lg rounded overflow-hidden" style="max-width: 900px;">

        <div class="col-lg-6 bg-white p-5">
            <div class="text-center mb-4">
                <img src="{{ asset('images/ITN.png') }}" alt="logo" width="80" class="mb-3">
                <h4 class="fw-bold">Create an Account</h4>
                <p class="text-muted mb-0">Join us, it's fast and easy!</p>
            </div>

            <form method="POST" action="">
                @csrf
                <div class="mb-3">
                    <label class="form-label">Full Name</label>
                    <div class="input-group">
                        <span class="input-group-text">
                            <i class="mdi mdi-account"></i>
                        </span>
                        <input 
                            type="text" 
                            name="name" 
                            class="form-control @error('name') is-invalid @enderror" 
                            value="{{ old('name') }}"
                            required 
                            placeholder="Enter your full name"
                        >
                        @error('name')
                            <span class="invalid-feedback d-block"><strong>{{ $message }}</strong></span>
                        @enderror
                    </div>
                </div>
                <div class="mb-3">
                    <label class="form-label">Email</label>
                    <div class="input-group">
                        <span class="input-group-text">
                            <i class="mdi mdi-email-outline"></i>
                        </span>
                        <input 
                            type="email" 
                            name="email" 
                            class="form-control @error('email') is-invalid @enderror" 
                            value="{{ old('email') }}"
                            required 
                            placeholder="Enter your email"
                        >
                        @error('email')
                            <span class="invalid-feedback d-block"><strong>{{ $message }}</strong></span>
                        @enderror
                    </div>
                </div>

                <div class="mb-3">
                    <label class="form-label">Password</label>
                    <div class="input-group">
                        <span class="input-group-text">
                            <i class="mdi mdi-lock-outline"></i>
                        </span>
                        <input 
                            type="password" 
                            name="password" 
                            class="form-control @error('password') is-invalid @enderror" 
                            required 
                            placeholder="Enter your password"
                        >
                        @error('password')
                            <span class="invalid-feedback d-block"><strong>{{ $message }}</strong></span>
                        @enderror
                    </div>
                </div>

                <div class="mb-3">
                    <label class="form-label">Confirm Password</label>
                    <div class="input-group">
                        <span class="input-group-text">
                            <i class="mdi mdi-lock-check"></i>
                        </span>
                        <input 
                            type="password" 
                            name="password_confirmation" 
                            class="form-control" 
                            required 
                            placeholder="Confirm your password"
                        >
                    </div>
                </div>

                <button class="btn btn-success w-100 py-2 mt-3">
                    Register
                </button>

                <p class="text-center mt-3">
                    Already have an account? 
                    <a href="{{ route('login') }}" class="text-primary">Login</a>
                </p>

            </form>
        </div>

        <div class="col-lg-6 d-none d-lg-flex justify-content-center align-items-end"
            style="background: linear-gradient(135deg, #1cc88a, #36b9cc); color: white;">

            <p class="p-4 text-center small">Create your account and get started today!</p>
        </div>

    </div>
</div>
@endsection
