@extends('layout.main')

@section('content')
<div class="container d-flex justify-content-center align-items-center" style="min-height: 100vh; margin-top: 100px;">
    <div class="row w-100 shadow-lg rounded overflow-hidden" style="max-width: 900px;">

        <div class="col-lg-6 bg-white p-5">
            
            <div class="text-center mb-4">
                <img src="{{ asset('images/ITN.png') }}" alt="logo" width="80" class="mb-3">
                <h4 class="fw-bold">Welcome Back!</h4>
                <p class="text-muted mb-0">Happy to see you again!</p>
            </div>

            <form method="POST" action="">
                @csrf

                <div class="mb-3">
                    <label class="form-label">Email</label>
                    <div class="input-group">
                        <span class="input-group-text">
                            <i class="mdi mdi-account-outline"></i>
                        </span>
                        <input 
                            id="email" 
                            type="email" 
                            class="form-control @error('email') is-invalid @enderror" 
                            name="email" 
                            value="{{ old('email') }}" 
                            required 
                            autofocus 
                            placeholder="Enter your email"
                        >
                        @error('email')
                            <span class="invalid-feedback d-block"><strong>{{ $message }}</strong></span>
                        @enderror
                    </div>
                </div>

                <div class="mb-3">
                    <label class="form-label">Password</label>
                    <div class="input-group">
                        <span class="input-group-text">
                            <i class="mdi mdi-lock-outline"></i>
                        </span>
                        <input 
                            id="password" 
                            type="password" 
                            class="form-control @error('password') is-invalid @enderror" 
                            name="password" 
                            required 
                            placeholder="Enter your password"
                        >
                        @error('password')
                            <span class="invalid-feedback d-block"><strong>{{ $message }}</strong></span>
                        @enderror
                    </div>
                </div>

                <button class="btn btn-primary w-100 py-2 mt-3">
                    Login
                </button>

                <p class="text-center mt-3">
                    Don't have an account?
                    <a href="{{ route('register') }}" class="text-primary">Register</a>
                </p>

            </form>
        </div>
        
        <div class="col-lg-6 d-none d-lg-flex justify-content-center align-items-end" 
            style="background: linear-gradient(135deg, #4e73df, #1cc88a); color: white;">
            
            <p class="p-4 text-center small">Copyright © {{ date('Y') }} All rights reserved.</p>
        </div>

    </div>
</div>
@endsection
