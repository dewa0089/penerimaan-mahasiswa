@extends('layout.main')

@section('content')
<div class="container" style="padding-top: 100px;">

    @if (Auth::user()->role == 'A')
        <h3 class="fw-bold mb-4">Proses Persetujuan Akun User</h3>

        @if (session('success'))
            <div class="alert alert-success">{{ session('success') }}</div>
        @endif

        <div class="card shadow">
            <div class="card-body">
                <table class="table table-bordered table-striped">
                    <thead class="table-primary">
                        <tr>
                            <th>No.</th>
                            <th>Nama</th>
                            <th>Email</th>
                            <th>Status Akun</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($users as $u)
                            <tr>
                                <td>{{ $loop->iteration }}</td>
                                <td>{{ $u->name }}</td>
                                <td>{{ $u->email }}</td>
                                <td>
                                    @if ($u->status == 'pending')
                                        <span class="badge bg-warning text-dark">Menunggu</span>
                                    @elseif ($u->status == 'approved')
                                        <span class="badge bg-success">Disetujui</span>
                                    @else
                                        <span class="badge bg-danger">Ditolak</span>
                                    @endif
                                </td>
                                <td>
                                    @if ($u->status == 'pending')
                                        <a href="{{ route('akun.approve', $u->id) }}"
                                           class="btn btn-success btn-sm">Setujui</a>

                                        <a href="{{ route('akun.reject', $u->id) }}"
                                           class="btn btn-danger btn-sm">Tolak</a>
                                    @else
                                        <small class="text-muted">Selesai</small>
                                    @endif
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    @else
    
        <h3 class="fw-bold mb-3">Status Akun Anda</h3>
        @if (session('message'))
            <div class="alert alert-info">{{ session('message') }}</div>
        @endif

        <div class="card shadow">
            <div class="card-body">
                <p><strong>Nama:</strong> {{ Auth::user()->name }}</p>
                <p><strong>Email:</strong> {{ Auth::user()->email }}</p>

                <p><strong>Status Akun:</strong>
                    @if (Auth::user()->status == 'pending')
                        <span class="badge bg-warning text-dark">Menunggu Persetujuan Admin</span>
                    @elseif (Auth::user()->status == 'approved')
                        <span class="badge bg-success">Disetujui</span>
                    @else
                        <span class="badge bg-danger">Ditolak</span>
                    @endif
                </p>

                @if (Auth::user()->status != 'approved')
                    <div class="alert alert-info mt-3">
                        Anda belum dapat mengakses menu pendaftaran & pembayaran
                        sampai admin menyetujui akun Anda.
                    </div>
                @endif
            </div>
        </div>

    @endif

</div>
@endsection
