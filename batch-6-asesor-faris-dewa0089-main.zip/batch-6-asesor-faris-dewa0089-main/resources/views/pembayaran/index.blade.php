@extends('layout.main')
@section('title', 'Pembayaran')

@section('content')
<div class="container py-5 mt-5">
    @foreach($pendaftar as $p)
    @php
        $pembayaran = $p->pembayaran;
    @endphp

    <div class="card shadow-sm border-0 p-4 mb-4" style="border-radius:16px;">
        <div class="row g-4">

            {{-- ========================= --}}
            {{-- RINCIAN PENDAFTAR --}}
            {{-- ========================= --}}
            <div class="col-md-4">
                <h4 class="fw-bold mb-3">Rincian Pendaftar</h4>

                <p><strong>Nama:</strong> {{ $p->nama }}</p>
                <p><strong>Jenis Kelamin:</strong> {{ $p->jk === 'L' ? 'Laki-laki' : 'Perempuan' }}</p>
                <p><strong>Program Studi:</strong> {{ $p->jurusan }}</p>
                <p><strong>NISN:</strong> {{ $p->nisn }}</p>
                <p><strong>Nomor WA:</strong> {{ $p->nomor }}</p>
                <p><strong>Email :</strong> {{ $p->email }}</p>
                <p><strong>Tanggal Lahir:</strong> {{ $p->tgl_lahir }}</p>
                <p><strong>Alamat:</strong> {{ $p->alamat }}</p>
                <p><strong>Agama:</strong> {{ $p->agama }}</p>

                <p><strong>Status Pendaftaran:</strong> 
                    @php
                        $statusPendaftaran = $p->status ?? 'pending';
                        $badgePendaftaran = $statusPendaftaran === 'Pendaftaran Diterima'
                            ? 'success'
                            : ($statusPendaftaran === 'Pendaftaran Ditolak' ? 'danger' : 'warning');
                    @endphp
                    <span class="badge bg-{{ $badgePendaftaran }}">{{ $statusPendaftaran }}</span>
                </p>

                {{-- Tombol admin terima/tolak pendaftaran --}}
                @if (auth()->user()->role === 'A' && $p->status === 'pending')
                    <div class="d-flex gap-2 mt-3">
                        <button class="btn btn-success btn-sm flex-fill approve-pendaftaran" data-id="{{ $p->id }}">Terima</button>
                        <button class="btn btn-danger btn-sm flex-fill reject-pendaftaran" data-id="{{ $p->id }}">Tolak</button>
                    </div>
                @endif
            </div>



            {{-- ================================ --}}
            {{-- RINCIAN PEMBAYARAN --}}
            {{-- ================================ --}}
            <div class="col-md-4">
                <h4 class="fw-bold mb-3">Rincian Pembayaran</h4>

                @if($p->status !== 'Pendaftaran Diterima')
                    <p class="text-muted">Menunggu pendaftaran diterima.</p>
                @else
                    <h5 class="fw-semibold mb-2">Biaya Pendaftaran</h5>
                    <p class="fs-4 fw-bold" style="color:#6d62ff;">
                        Rp {{ number_format($pembayaran->total_pembayaran ?? 0, 0, ',', '.') }}
                    </p>

                    <p><strong>Tanggal Pembayaran:</strong> {{ $pembayaran->tgl_pembayaran ?? '-' }}</p>
                    <p><strong>Tanggal Jatuh Tempo:</strong> {{ $pembayaran->tgl_tempo ?? '-' }}</p>

                    <p><strong>Status Pembayaran:</strong> 
                        @php
                            $statusBayar = $pembayaran->status ?? 'pending';
                            $badgeBayar = $statusBayar === 'Pembayaran Diterima'
                                ? 'success'
                                : ($statusBayar === 'Pembayaran Ditolak' ? 'danger' : 'warning');
                        @endphp
                        <span class="badge bg-{{ $badgeBayar }}">{{ $statusBayar }}</span>
                    </p>

                    <h5 class="fw-semibold mt-3">Instruksi Pembayaran</h5>
                    <p class="text-muted">Transfer ke rekening berikut:</p>
                    <ul style="list-style-type:none; padding-left:0;">
                        <li>Bank BCA – 123456789</li>
                        <li>a.n Institut Teknologi Nasional Malang</li>
                    </ul>

                    {{-- BUTTON ADMIN HANYA MUNCUL JIKA USER SUDAH UPLOAD BUKTI --}}
                    @if (auth()->user()->role === 'A' 
                        && $pembayaran 
                        && $pembayaran->bukti 
                        && $pembayaran->status === 'pending')

                        <div class="d-flex gap-2 mt-3">
                            <button class="btn btn-success btn-sm flex-fill approve-pembayaran" data-id="{{ $pembayaran->id }}">
                                Terima Pembayaran
                            </button>
                            <button class="btn btn-danger btn-sm flex-fill reject-pembayaran" data-id="{{ $pembayaran->id }}">
                                Tolak Pembayaran
                            </button>
                        </div>
                    @endif
                @endif
            </div>



            {{-- ================================ --}}
            {{-- BUKTI PEMBAYARAN --}}
            {{-- ================================ --}}
            <div class="col-md-4">
                <h4 class="fw-bold mb-3">Bukti Pembayaran</h4>

                @if($p->status !== 'Pendaftaran Diterima')
                    <p class="text-muted">Menunggu pendaftaran diterima.</p>
                @else
                    
                    @if(!empty($pembayaran->bukti))
                        {{-- Bukti sudah ada --}}
                        <img src="{{ asset('bukti/' . $pembayaran->bukti) }}"
                             class="img-fluid mt-2"
                             style="width:100%; border-radius:16px;">
                    
                    @else
                        {{-- User upload bukti --}}
                        @if(auth()->user()->role === 'U')
                            <form action="{{ route('pembayaran.upload', $pembayaran->id) }}" 
                                  method="POST" enctype="multipart/form-data">
                                @csrf
                                <input type="file" name="bukti" class="form-control" required>
                                <button type="submit" class="btn btn-primary mt-2 w-100">
                                    Konfirmasi Pembayaran
                                </button>
                            </form>
                        @endif
                    @endif

                @endif
            </div>

        </div>
    </div>
    @endforeach
</div>

@endsection
