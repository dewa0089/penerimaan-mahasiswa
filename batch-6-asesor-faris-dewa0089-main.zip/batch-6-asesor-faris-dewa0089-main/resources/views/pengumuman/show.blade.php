@extends('layout.main')
@section('title', $p->judul)

@section('content')

<div class="container py-5 mt-5">

    <div class="card shadow-sm border-0 p-4" style="border-radius:16px;">

        <h3 class="fw-bold mb-4">{{ $p->judul }}</h3>

        @if($p->gambar)
        <div class="text-center mb-4">
            <img src="{{ asset('upload/' . $p->gambar) }}" class="img-fluid"
                style="max-height:300px; border-radius:16px; object-fit:contain;">
        </div>
        @endif

        <div class="mt-3 mb-4" style="font-size:15px; line-height:1.7;">
            {!! nl2br(e($p->isi)) !!}
        </div>

        <hr>
        <div class="d-flex justify-content-between text-muted small mt-3">
            <div>
                Terakhir diperbarui: 
                <b>{{ \Carbon\Carbon::parse($p->tgl_pengumuman)->translatedFormat('d M Y') }}</b>
            </div>
            <div>
                Oleh: <b>Admin</b>
            </div>
        </div>

        <div class="mt-4">
            <a href="{{ route('pengumuman.index') }}" class="btn btn-secondary px-4">Kembali</a>
        </div>

    </div>

</div>

@endsection
