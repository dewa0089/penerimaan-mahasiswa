@extends('layout.main')
@section('title', 'Tambah Pengumuman')

@section('content')

<div class="container py-5 mt-5">

    <div class="row g-4">

        <div class="col-lg-12">

            <div class="card shadow-sm border-0 p-4" style="border-radius:16px;">
                
                <h4 class="fw-bold mb-1">Formulir Pembuatan Pengumuman</h4>
                <h5 class="fw-semibold mb-3">Informasi Pengumuman</h5>

                <form action="{{ route('pengumuman.store') }}" method="POST" enctype="multipart/form-data">
                    @csrf

                    <div class="mb-4">
                        <label class="form-label fw-semibold">Judul Pengumuman</label>
                        <input type="text" class="form-control" name="judul" placeholder="Judul Pengumuman" required>
                    </div>
                    
                    <div class="mb-4">
                        <label class="form-label fw-semibold">Isi Pengumuman</label>
                        <textarea class="form-control" name="isi"
          placeholder="Tulis isi pengumuman..." required
          style="min-height: 250px; resize: vertical;"></textarea>

                    </div>

                    <div class="mb-4">
                        <label class="form-label fw-semibold">Unggah Gambar</label>
                        <input type="file" class="form-control" name="gambar" accept="image/*">
                        <small class="text-muted">Format yang didukung: JPG, PNG, JPEG</small>
                    </div>

                    <button type="submit" class="btn w-100 text-white fw-semibold"
                            style="background:#6d62ff; padding:10px 0; border-radius:8px;">
                        Upload Pengumuman
                    </button>

                </form>

            </div>
        </div>

    </div>

</div>

@endsection
