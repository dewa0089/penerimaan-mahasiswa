@extends('layout.main')
@section('title', 'Pengumuman')

@section('content')
<div class="container py-5 mt-5">

    <div class="card shadow-sm border-0 p-4" style="border-radius:16px; gap:10px; margin-bottom:20px;">

        <div class="d-flex justify-content-between align-items-center mb-3">
            <h4 class="fw-bold m-0">Pengumuman</h4>

            @auth
            @if (auth()->user()->role === 'A')
            <a href="{{ route('pengumuman.create') }}" class="btn btn-primary">
                Tambah Pengumuman
            </a>
            @endif
            @endauth
        </div>

        <div class="row g-4">
            @foreach($data as $p)
            <div class="col-lg-6 col-md-6 col-12">

                <div class="p-1" style="background:#eee; border-radius:20px; height:100%;">
                    <div class="card shadow-sm border-0 p-3 position-relative d-flex flex-column h-100"
                         style="border-radius:16px; background:white; cursor:pointer; transition:0.2s;"
                         onclick="window.location='{{ route('pengumuman.show', $p->id) }}'">

                        @auth
                        @if(auth()->user()->role === 'A')
                        <div class="position-absolute bottom-0 end-0 mb-2 me-2 d-flex gap-2">

                            <a href="{{ route('pengumuman.edit', $p->id) }}"
                               class="btn btn-sm btn-warning"
                               style="padding:4px 8px; border-radius:8px; z-index:20;"
                               onclick="event.stopPropagation();">
                                Edit
                            </a>

                            <form id="delete-form-{{ $p->id }}" 
                                  action="{{ route('pengumuman.destroy', $p->id) }}" 
                                  method="POST"
                                  style="z-index:20;"
                                  onclick="event.stopPropagation();">
                                @csrf
                                @method('DELETE')

                                <button 
                                    type="button" 
                                    class="btn btn-sm btn-danger delete-btn"
                                    data-id="{{ $p->id }}"
                                    style="padding:4px 8px; border-radius:8px;"
                                    onclick="event.stopPropagation();">
                                    Delete
                                </button>

                            </form>
                        </div>
                        @endif
                        @endauth

                        <h6 class="fw-bold mb-2 text-truncate" style="max-height: 3em;">
                            {{ $p->judul }}
                        </h6>

                        @if($p->gambar)
                        <img src="{{ asset('upload/' . $p->gambar) }}"
                             class="img-fluid rounded mb-3"
                             style="border-radius:16px; max-height:180px; object-fit:cover; width:100%;">
                        @else
                        <div style="height:180px;"></div>
                        @endif

                        <p class="text-muted small mb-1 flex-grow-1"
                           style="
                                display: -webkit-box;
                                -webkit-line-clamp: 2;
                                -webkit-box-orient: vertical;
                                overflow: hidden;
                                text-overflow: ellipsis;
                           ">
                            {{ $p->isi }}
                        </p>

                        <span class="text-muted small mt-auto">
                            {{ $p->tgl_pengumuman }}
                        </span>

                    </div>
                </div>

            </div>
            @endforeach
        </div>

    </div>

</div>

@endsection
