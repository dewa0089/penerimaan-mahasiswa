@extends('layout.main')
@section('title', 'Edit Pengumuman')

@section('content')
<div class="container py-5 mt-5">

    <div class="card shadow-sm border-0 p-4" style="border-radius:16px; max-width:700px; margin:auto;">

        <h4 class="fw-bold mb-4">Edit Pengumuman</h4>

        <form action="{{ route('pengumuman.update', $p->id) }}" method="POST" enctype="multipart/form-data">
            @csrf
            @method('PUT')

            <div class="mb-3">
                <label class="form-label">Judul</label>
                <input type="text" name="judul" class="form-control" value="{{ old('judul', $p->judul) }}" required>
            </div>

            <div class="mb-3">
                <label class="form-label">Isi Pengumuman</label>
                <textarea name="isi"  class="form-control" style="min-height: 250px; resize: vertical;" rows="6" required>{{ old('isi', $p->isi) }}</textarea>
            </div>

            <div class="mb-3">
                <label class="form-label">Gambar (Opsional)</label>
                <input type="file" name="gambar" class="form-control">

                @if($p->gambar)
                <div class="mt-3">
                    <p class="text-muted small">Gambar saat ini:</p>
                    <img src="{{ asset('upload/' . $p->gambar) }}" 
                         class="img-fluid rounded"
                         style="max-height:200px;">
                </div>
                @endif
            </div>

            <div class="d-flex justify-content-between mt-4">
                <a href="{{ route('pengumuman.index') }}" class="btn btn-secondary px-4">Kembali</a>
                <button type="submit" class="btn btn-primary px-4">Simpan Perubahan</button>
            </div>

        </form>

    </div>

</div>
@endsection
